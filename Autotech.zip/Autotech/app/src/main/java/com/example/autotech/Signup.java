package com.example.autotech;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;

public class Signup extends AppCompatActivity {

    EditText e1, e2, e3, e4, e5;
    String Username, Mailid, password, ContactNumber, Address;
    Button b1;
    FirebaseAuth fAuth;
    //ProgressBar progressBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        e1 = findViewById(R.id.year);
        e2 = findViewById(R.id.editText4);
        e3 = findViewById(R.id.editText8);
        e4 = findViewById(R.id.editText7);
        e5 = findViewById(R.id.editText6);
        b1 = findViewById(R.id.button2);
        fAuth = FirebaseAuth .getInstance();
        if (fAuth.getCurrentUser() != null){
            startActivity(new Intent(getApplicationContext(),Login.class));
            finish();
        }
      //  progressBar = findViewById(R.id.);
        e1.setText(Username);
        e2.setText(Mailid);
        e3.setText(password);
        e4.setText(ContactNumber);
        e5.setText(Address);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Username = e1.getText().toString().trim();
                Mailid = e2.getText().toString().trim();
                password = e3.getText().toString().trim();
                ContactNumber = e4.getText().toString().trim();
                Address = e5.getText().toString().trim();
                 /* if (TextUtils.isEmpty(Mailid)){
                      Mailid.("");
                  }*/
                 fAuth.createUserWithEmailAndPassword(Mailid,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                     @Override
                     public void onComplete(@NonNull Task<AuthResult> task) {
                         if(task.isSuccessful()){
                             Toast.makeText(Signup.this,"user created",Toast.LENGTH_SHORT).show();
                             startActivity(new Intent(getApplicationContext(),Login.class));
                         }else{
                             Toast.makeText(Signup.this,"Error !" ,Toast.LENGTH_SHORT ).show();

                         }
                     }
                 });


             /*   Intent i1 = new Intent(Signup.this, Login.class);
                i1.putExtra("key5", "Username");
                i1.putExtra("key6", "Mail id");
                i1.putExtra("key7", "Password");
                i1.putExtra("key8", "ContactNumber");
                i1.putExtra("key9", "Address");
                startActivity(i1);*/

            }
        });

    }
}
